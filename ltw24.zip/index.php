<?php
    header('Location: ./pages/initialPage.php');
?>